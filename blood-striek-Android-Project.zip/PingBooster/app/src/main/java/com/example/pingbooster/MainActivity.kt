package com.example.pingbooster

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.net.InetAddress
import kotlin.concurrent.thread

class MainActivity: Activity() {
 private lateinit var ping: TextView
 override fun onCreate(b: Bundle?) { super.onCreate(b)
  val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(28,36,28,28); root.setBackgroundColor(Color.rgb(16,24,39))
  fun tv(t:String,s:Float)=TextView(this).apply{ text=t; textSize=s; setTextColor(Color.WHITE); gravity=Gravity.CENTER }
  root.addView(tv("⚡ BLOOD STRIEK",26f), LinearLayout.LayoutParams(-1,80))
  ping=tv("-- ms\nCURRENT PING",30f); root.addView(ping,LinearLayout.LayoutParams(-1,180))
  val info=tv("اختبر الاتصال لمعرفة البينج والجيتّر.\nالتطبيق لا يضمن خفض البينج ولا يغيّر سيرفر اللعبة.",16f); root.addView(info,LinearLayout.LayoutParams(-1,100))
  val btn=Button(this); btn.text="START NETWORK TEST"; root.addView(btn,LinearLayout.LayoutParams(-1,70)); btn.setOnClickListener{ test() }
  root.addView(tv("نصائح: استخدم Wi‑Fi 5GHz، أغلق التنزيلات، واختر أقرب سيرفر داخل اللعبة.",14f),LinearLayout.LayoutParams(-1,120)); setContentView(root)
 }
 private fun test(){ ping.text="Testing..."; thread { val start=System.nanoTime(); try { InetAddress.getByName("1.1.1.1").isReachable(3000); val ms=(System.nanoTime()-start)/1_000_000; runOnUiThread{ping.text="$ms ms\nCURRENT PING"} } catch(e:Exception){runOnUiThread{ping.text="Failed\nCHECK NETWORK"}} }
 }
}
